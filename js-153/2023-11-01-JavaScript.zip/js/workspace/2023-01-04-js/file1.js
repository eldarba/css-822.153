// this is JavaScript only
console.log("Hello from JS file");