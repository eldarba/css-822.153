import val, { person as man, sum, Point } from './util-module.js';


let person = 6;

console.log(val);
console.log(man);
console.log(person);
console.log(sum(3, 7));
let p1 = new Point(100, 200);
console.log(p1);


