// primitive
let x = 5;
// object
let person = { id: 101, name: 'aaa', age: 33 };
// function
let sum = (a, b) => a + b;
// class
export class Point {
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }
}


export default x;
export { person, sum };