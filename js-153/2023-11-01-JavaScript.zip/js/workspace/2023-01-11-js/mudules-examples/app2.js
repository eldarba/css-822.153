import * as util from './util-module.js'

console.log("=================");
console.log(util.default);

let p = new util.Point(3, 9);
console.log(p);